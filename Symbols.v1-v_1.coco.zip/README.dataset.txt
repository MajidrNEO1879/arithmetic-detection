# Symbols > v_1
https://universe.roboflow.com/freelance-v8hyx/symbols-12pvo-iwz2p

Provided by a Roboflow user
License: CC BY 4.0

